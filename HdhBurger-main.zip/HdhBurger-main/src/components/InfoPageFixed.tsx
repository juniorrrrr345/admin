'use client';
import { useState, useEffect } from 'react';
import BottomNav from './BottomNav';
import { instantContent } from '@/lib/contentCache';

interface InfoPageProps {
  onClose: () => void;
  activeTab?: string;
  onTabChange?: (tabId: string) => void;
}

export default function InfoPageFixed({ onClose, activeTab = 'infos', onTabChange }: InfoPageProps) {
  // Utiliser directement les données du cache instantané
  const settings = instantContent.getSettings();
  const pageContent = instantContent.getInfoContent();

  const handleTabChange = (tabId: string) => {
    if (onTabChange) {
      onTabChange(tabId);
    }
  };

  // Background simple et direct - MÊME que page menu
  const backgroundStyle = settings?.backgroundImage ? {
    backgroundColor: 'black',
    backgroundImage: `url(${settings.backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
    backgroundRepeat: 'no-repeat'
  } : { backgroundColor: 'black' };

  const overlayStyle = settings?.backgroundImage ? {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: `rgba(0, 0, 0, ${(settings?.backgroundOpacity || 20) / 100})`,
    backdropFilter: `blur(${settings?.backgroundBlur || 5}px)`,
    pointerEvents: 'none' as const,
    zIndex: 0
  } : {};

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto min-h-screen" style={backgroundStyle}>
      {/* Overlay */}
      {settings?.backgroundImage && <div style={overlayStyle}></div>}
      
      {/* Contenu */}
      <div className="relative z-10 min-h-screen">
        {/* Header */}
        <div className="sticky top-0 bg-black/95 backdrop-blur-sm p-4 flex items-center justify-between border-b border-white/20 z-20">
          <button
            onClick={onClose}
            className="text-white hover:text-gray-300 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-white">Informations</h1>
          <div className="w-6"></div>
        </div>

        {/* Contenu de la page */}
        <div className="flex-1 p-6">
          <div className="max-w-2xl mx-auto">
            <div className="bg-gray-900/80 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              {pageContent.split('\n').map((line: string, index: number) => {
                // Titres H1
                if (line.startsWith('# ')) {
                  return (
                    <h1 key={index} className="text-3xl font-bold text-white mb-6 mt-8 first:mt-0">
                      {line.substring(2)}
                    </h1>
                  );
                }
                // Titres H2
                if (line.startsWith('## ')) {
                  return (
                    <h2 key={index} className="text-2xl font-bold text-white mb-4 mt-6">
                      {line.substring(3)}
                    </h2>
                  );
                }
                // Titres H3
                if (line.startsWith('### ')) {
                  return (
                    <h3 key={index} className="text-xl font-bold text-white mb-3 mt-4">
                      {line.substring(4)}
                    </h3>
                  );
                }
                // Listes à puces
                if (line.startsWith('- ')) {
                  return (
                    <li key={index} className="text-gray-200 ml-4 mb-2 list-disc">
                      {line.substring(2)}
                    </li>
                  );
                }
                // Lignes vides
                if (line.trim() === '') {
                  return <br key={index} />;
                }
                // Texte normal
                return (
                  <p key={index} className="text-gray-200 leading-relaxed mb-3">
                    {line.split('**').map((part, i) => 
                      i % 2 === 1 ? <strong key={i} className="text-white font-bold">{part}</strong> : part
                    )}
                  </p>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
      </div>
    </div>
  );
}