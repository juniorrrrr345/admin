// Utilise la version runtime pour éviter les erreurs de build
export { default } from './mongodb-runtime';